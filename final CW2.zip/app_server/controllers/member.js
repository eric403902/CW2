
var express = require('express');
var createError = require('http-errors');
var modelmember = require('../models/member');

module.exports.display = function(req, res, next) {
    var userName=req.params.username;
    
    modelmember.displayuser(userName,function(err, results) {
        console.log(1);
        if (err) return next(createError(500));
        modelmember.displaysong(function(err, result2) {
            console.log(2);
            if (err) return next(createError(500));
            modelmember.displaybuylist(userName,function(err, result3) {
                console.log(3);
                if (err) return next(createError(500));
                modelmember.displayrefund(userName,function(err, result4) {
                    console.log(4);
                    if (err) return next(createError(500));  
                    res.render('member',{scollection:result2,tcollection:result4 ,bcollection:result3,title:'staff',name:results[0].username,point:results[0].point,money:results[0].money});
                });
            });
        });
    });
  }

module.exports.creatt = function(req,res,next){
    var point=req.body.points_use,
    buy=req.body.buy,
    username=req.body.username,
    money=req.body.money;

   // console.log(!buy);
    if(point == ''){point=0;}
    //console.log('P:'+point);
    if(!buy || money<=0){res.redirect('/member'+'/'+req.body.username);}
    else{
            modelmember.creatt(username,buy,point,function(err, tid) {
                console.log(2.1);
                if (err) return next(createError(500));
                modelmember.updateuser(username,tid,function(err, results) {
                    console.log(2.2);
                    if (err) return next(createError(500));
                    modelmember.updatelist(username,buy,tid,function(err, results) {
                        console.log(2.3);
                        if (err) return next(createError(500));

                            return next();
                      
                    });
                });
            });
        }
    
}



module.exports.updatedisplay = function(req,res,next){
    console.log(5);
    res.redirect('/member'+'/'+req.body.username);
}
module.exports.refund = function(req,res,next){
    console.log('REQ'+JSON.stringify(req.params));
    console.log('BODY'+JSON.stringify(req.body));
    var rid = req.params.rid,
        username = req.body.username,
        returnpay = parseInt(req.body.moneyuse);
        modelmember.changestate(rid,function(err, r1) {
            console.log(3.1);
            if (err) return next(createError(500));
            modelmember.returnmoney(username,returnpay,function(err, r2) {
                console.log(3.2);
                if (err) return next(createError(500));
                modelmember.returnsell(rid,function(err, r3) {
                    console.log(3.3);
                    if (err) return next(createError(500));
                    modelmember.returnproduct(rid,function(err, r4) {
                        console.log(3.4);
                        if (err) return next(createError(500));
                    return next();
                    });  
                });
            });
        });

}
  
