module.exports = function(req, res, next) {
    if (!req.session.views) {
        req.session.views = {}
      }
     
      // count the views
      if (!req.session.views[req.path]) req.session.views[req.path] = 0;
      req.session.views[req.path] += 1;
      return next();
    }