
var express = require('express');
var createError = require('http-errors');
var modelstaff = require('../models/staff');
module.exports.display = function(req, res, next) {
    //require staff.js in model to access DB
    //select song information and calulate the sum of attribute "purchase number" in song table
    //select attribute "refund state" in transaction table and calulate number of success(S) and reject(R) 
    //output result in corresponsed table
    if(!req.params.username) {var userName=req.body.username;}
    else{var userName=req.params.username;}
    
    modelstaff.displayuser(userName,function(err, results) {
      if (err) return next(createError(500));
      modelstaff.displaysong(function(err, result2) {
        if (err) return next(createError(500));
        modelstaff.displaytransaction(function(err, result3) {
          if (err) return next(createError(500));
         res.render('staff',{title:'staff',name:results[0].username,scollection:result2,totals:result3[0].totals,totalp:result3[0].totalp});
        }); 
      });

  });
}

module.exports.delete = function(req,res,next){
  var did = req.params.did;
  modelstaff.delsong(did,function(err, results) {
    if (err) return next(createError(500));
    res.redirect('/staff'+'/'+req.body.username);
  });
}

module.exports.change = function(req,res,next){
var sid = req.body.sid,
    price = req.body.price,
    detail = req.body.detail,
    inventory = req.body.inventory;
    modelstaff.changesong(sid,price,detail,inventory,function(err, results) {
      if (err) return next(createError(500));
      res.redirect('/staff'+'/'+req.body.username);
    });
}

module.exports.create = function(req, res, next) {
    //insert new entire into song table
    var songname = req.body.songname,
    price = req.body.price,
    detail = req.body.detail,
    inventory = req.body.inventory,
    path = req.body.path,
    testpath = req.body.testpath;
    modelstaff.createsong(songname,price,detail,inventory,path,testpath,function(err, results) {
      if (err) return next(createError(500));
      res.redirect('/staff'+'/'+req.body.username);
    });
  }

module.exports.updatedisplay = function(req,res,next){
  modelstaff.displaysong(function(err, result2) {
    if (err) return next(createError(500));
    modelstaff.displaytransaction(function(err, result3) {
      if (err) return next(createError(500));
     res.render('staff',{title:'staff',scollection:result2,totals:result3[0].totals,totalp:result3[0].totalp});
    }); 
  });
  
}







