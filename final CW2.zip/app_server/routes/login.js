

var express = require('express'),
    User = require('../models/login.js'),
    router = express.Router(),
    crypto = require('crypto'),
    path = require('path');
 


router.get('/', function(req, res) {
    res.locals.error = '';
    res.render('login');
});


router.post('/', function(req, res) {
    var userName = req.body.username,
        userPwd = req.body.password,
        md5 = crypto.createHash('md5');
        User.getUserByUserName(userName, function (err, results) {   
                                
        if(results == '') {
            res.locals.error = 'account is not exist';
            res.render('login');
            return;
        }


      
      
        if(results[0].username != userName || results[0].password != userPwd) {
            res.locals.error = 'invalid usename or password';
            res.render('login');
            return;
        } 

        if(results[0].username == userName && results[0].password == userPwd && results[0].userstate == 'm')
        {   
            userPwd = md5.update(userPwd).digest('hex');
            res.username = userName;
            req.session.username = res.username;      
            res.redirect('/member'+'/'+userName);
            return;
        }   
        if(results[0].username == userName && results[0].password == userPwd && results[0].userstate == 's')
        {   
            userPwd = md5.update(userPwd).digest('hex');
            res.locals.username = userName;
            req.session.username = res.locals.username; 
            res.redirect('/staff'+'/'+userName);                     
            return;
        }    

    });             
});


module.exports = router;
 