var express = require('express');
var router = express.Router();
var controllermember = require('../controllers/member');

/* GET home page. */

/*router.get('/',isLoggedIn,function(req, res) {

    res.redirect(307,'/');}
);
router.post('/',isLoggedIn,

    controllermember.display
);*/
router.get('/:username',isLoggedIn,controllermember.display);
//router.post('/buy', controllermember.buy);
//router.post('/buy', function(req, res, next) {console.log(req.body.buy),controllermember.buy});
router.post('/buy',controllermember.creatt,controllermember.updatedisplay);

router.put('/refund/:rid', controllermember.refund,controllermember.updatedisplay);






function isLoggedIn(req, res, next) {

    if (req.session.username)
      return next();
    else res.redirect('/logout');
}
module.exports = router;