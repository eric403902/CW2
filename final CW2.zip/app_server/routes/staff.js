var express = require('express');
var router = express.Router();
var controllerstaff = require('../controllers/staff');
/* GET home page. */
router.get('/',isLoggedIn,controllerstaff.updatedisplay);
router.get('/:username',isLoggedIn,controllerstaff.display);
router.delete('/delete/:did', controllerstaff.delete, controllerstaff.updatedisplay);
router.put('/change', controllerstaff.change, controllerstaff.updatedisplay);
router.post('/create', controllerstaff.create, controllerstaff.updatedisplay);

function isLoggedIn(req, res, next) {

    if (req.session.username)
      return next();
    else res.redirect('/logout');
}

module.exports = router;
