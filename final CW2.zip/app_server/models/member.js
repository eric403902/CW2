var mysql = require('mysql');
    
var pool  = mysql.createPool({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database: 'cw2'
});


module.exports.displayuser = function displayuser (userName, callback) {  
    
    pool.getConnection(function(err, connection){
         var cmd = "select * from user where username = ?";
         connection.query(cmd, [userName], function (err, result) {
             if (err) {
                 return;
             }
             connection.release();
             callback(err,result);                    
         });  
        });     
     }


module.exports.displaysong = function displaysong (callback){
    pool.getConnection(function(err, connection){
        var cmd = "select * from song";
        connection.query(cmd, function (err, result2) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result2);                    
        });  
    });  
}

module.exports.displaybuylist = function displaybuylist (userName,callback){
    pool.getConnection(function(err, connection){
        console.log(userName);
        var cmd = "select distinct songname,path from buylist where owner = ?";
        connection.query(cmd,[userName], function (err, result3) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result3);                    
        });  
    });  
}
module.exports.displayrefund = function displayrefund (userName,callback){
    pool.getConnection(function(err, connection){
        var cmd = "select * from transaction where buyer = ?";
        connection.query(cmd,[userName], function (err, result4) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result4);                    
        });  
    });  
}
module.exports.creatt = function creat(username,buy,point,callback){
    console.log("model creatt start");
    var state="CN"
    if (point == 0){state = 'C';}
        pool.getConnection(function(err, connection){
            var cmdtid = "select MAX(tid) AS 'MAX' from transaction" ;
            var cmdctt = "insert into transaction set ?" ;
            connection.query(cmdtid, function (err,max){
                if (err){
                    return;
                }
                connection.query(cmdctt,
                    {   
                        tid:max[0].MAX+1,
                        date:new Date(),
                        buyer:username,
                        tstate:state,
                        money_use:0,
                        point_use:point
                    }, 
                    function (err,insert){
                        if (err){
                            throw err;
                        }
                        var sum = 0;
                        var cmd1 = "select price from song where sid = ?";
                        var cmd2 = "update transaction set ? where tid = ?";

                        for(let i=0;i<buy.length;i++){
                            song=buy[i];
                            connection.query(cmd1,[song],function(err,result){
                                if(err){
                                    throw err;
                                }
                                sum = sum+result[0].price;
                                if(i == buy.length-1){
                                    connection.query(cmd2,[{money_use:sum},max[0].MAX+1],function(err,result){
                                        if(err){
                                            throw err;
                                        } 
                                        connection.release();
                                        callback(err,max[0].MAX+1);
                                    });
                                }
                            });
                        }   
                });
            });    
        });        
        
    }

module.exports.updateuser = function(username,result1,callback){
    console.log("model updateuser start");
    pool.getConnection(function(err, connection){
        var cmd1 = "select * from user where username = ?";
        var cmd2 = "select * from transaction where tid = ?";
        var cmd3 = "update user set ? where username = ?";
        connection.query(cmd1,[username], function (err, u) {
            if (err) {
                return;
            }
            connection.query(cmd2,[result1], function (err, t) {
                if (err) {
                    return;
                }
                connection.query(cmd3,[{money:u[0].money-t[0].money_use+t[0].point_use,point:u[0].point-t[0].point_use},username], function (err, result3) {
                    if (err) {
                        return;
                    }

                    connection.release();
                    callback(err,u);   
                });
            });                
        });  
    });  
}

module.exports.updatelist = function(username,buy,tid,callback){
    console.log('model updatesonglist start')
    if(buy.length==1){
        pool.getConnection(function(err, connection){
                var cmd1 = "select * from song where sid = ?";
                var cmd2 = "update song set ? where sid = ?";
                var cmd3 = "insert into buylist set ?" ;
                connection.query(cmd1,[buy],function (err, s) {
                    if (err) {
                        return;
                    }
                    connection.query(cmd2,[{inventory:s[0].inventory-1,sell:s[0].sell+1},buy],function (err, n1) {
                        if (err) {
                            return;
                        }
                        connection.query(cmd3,[{owner:username,path:s[0].path,songname:s[0].songname,tid:tid}],function (err, n2) {
                            if (err) {
                                throw err;
                            }
                            callback(err,s);
                        }); 
                    });                   
                }); 
            
                connection.release();
        });
    }
    else{
                pool.getConnection(function(err, connection){
                        buy.forEach(song => {
                            
                            var cmd1 = "select * from song where sid = ?";
                            var cmd2 = "update song set ? where sid = ?";
                            var cmd3 = "insert into buylist set ?" ;
                            connection.query(cmd1,[song],function (err, s) {
                                if (err) {
                                    throw err;
                                }
                                connection.query(cmd2,[{inventory:s[0].inventory-1,sell:s[0].sell+1},song],function (err, n1) {
                                    if (err) {
                                        throw err;
                                    }
                                    connection.query(cmd3,[{owner:username,path:s[0].path,songname:s[0].songname,tid:tid}],function (err, n2) {
                                        if (err) {
                                            throw err;
                                        }
                                        callback(err,s);
                                    }); 
                                 
                                });  
                                               
                            }); 
                        });
                     connection.release(); 
                           
                });  
    }
}

module.exports.changestate = function(rid,callback){
    pool.getConnection(function(err, connection){
        var cmd = "update transaction set ? where tid = ?"
        connection.query(cmd,[{tstate:"S"},rid], function (err, result) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result);                    
        });  
    });  
}

module.exports.returnmoney = function(username,returnpay,callback){
    pool.getConnection(function(err, connection){
        var cmd1 = "select * from user where username = ?"
        var cmd2 = "update user set ? where username = ?"
        connection.query(cmd1,[username], function (err, u) {
            if (err) {
                return;
            }
            connection.query(cmd2,[{money:u[0].money+returnpay},username], function (err, result) {
                if (err) {
                    return;
                }
                connection.release();
                callback(err,result);                    
            }); 
        }); 
    }); 
}

module.exports.returnsell = function(rid,callback){
    pool.getConnection(function(err, connection){
        var cmd1 = "select songname from buylist where tid = ?";
        connection.query(cmd1,[rid], function (err, s) {
            if (err) {
                throw err;
            }
            s.forEach(sname => {
                
                var cmd2 = "select inventory,sell from song where songname = ?";
                connection.query(cmd2,[sname.songname], function (err, s2) {
                    if (err) {
                        throw err;
                    }
                        var cmd3 = "update song set ? where songname = ?";
                        connection.query(cmd3,[{inventory:s2[0].inventory+1,sell:s2[0].sell-1},sname.songname], function (err, s3) {
                            if (err) {
                                throw err;
                            }  
                        });
                    
                });
            });
            callback(err,s);
            connection.release(); 
        });
    });
}


module.exports.returnproduct = function(rid,callback){
    pool.getConnection(function(err, connection){
        var cmd4 = 'delete from buylist where tid=?'; 
        connection.query(cmd4,[rid], function (err,r5) {
            if (err) {
                throw err;
            }
            callback(err,r5);
            connection.release(); 
        });
    });
}







































/*module.exports.updatebuylist = function(username,buy,tid,callback){
    console.log("BUY:"+buy);
    var cmd1 = "select * from song where sid = ?";
    var cmd2 = "insert into buylist set ?" ;
        for(let i=0;i<buy.length;i++)
           { 
            var song=buy[i];
            pool.getConnection(function(err, connection){
            connection.query(cmd1,[song],function (err, s) {
                if (err) {
                    throw err;
                }
                connection.query(cmd2,[{owner:username,path:s[0].path,songname:s[0].songname,tid:tid}],function (err, n) {
                    if (err) {
                        throw err;
                    }
                    callback(err,n);
                }); 
                connection.release();                   
                });
            }); 
        }
  

}*/

