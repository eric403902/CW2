var mysql = require('mysql');

var pool  = mysql.createPool({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database: 'cw2'
});

module.exports.getUserByUserName = function getUserNumByName(username, callback) {

        pool.getConnection(function(err, connection){
            var cmd = "select * from user where username = ?";
            connection.query(cmd, [username], function (err, result) {
                if (err) {
                    return;
                }
                console.log(JSON.stringify(result));
                connection.release();
                callback(err,result);                    
            });  
            });     
 }

