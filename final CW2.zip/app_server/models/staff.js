var mysql = require('mysql');
    
var pool  = mysql.createPool({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database: 'cw2'
});


module.exports.displayuser = function displayuser(username, callback) {
    pool.getConnection(function(err, connection){
         var cmd = "select * from user where username = ?";
         connection.query(cmd, [username], function (err, result) {
             if (err) {
                 return;
             }
             console.log(JSON.stringify(result));
             connection.release();
             callback(err,result);                    
         });  
        });     
     }

module.exports.displaysong = function displaysong (callback){
    pool.getConnection(function(err, connection){
        var cmd = "select * from song";
        connection.query(cmd, function (err, result2) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result2);                    
        });  
    });  
}

module.exports.displaytransaction = function (callback){
    pool.getConnection(function(err, connection){
        var cmd = ' SELECT SUM(CASE WHEN tstate = "S" THEN 1 ELSE 0 END) AS totals, SUM(point_use) AS totalp FROM transaction';
        connection.query(cmd,function (err, result2) {
            if (err) {
                return;
            }
            connection.release();
            callback(err,result2);                    
        });  
    });  
}

module.exports.delsong = function(did,callback){
    pool.getConnection(function(err, connection){
        var cmd = 'delete from song where sid=?'; 
        connection.query(cmd,[did], function (err,r) {
            if (err) {
                throw err;
            }
            callback(err,r);
            connection.release(); 
        });
    });
}

module.exports.changesong = function(sid,price,detail,inventory,callback){
    pool.getConnection(function(err, connection){
        var cmd = "update song set ? where sid = ?"; 
        connection.query(cmd,[{price:price,detail:detail,inventory:inventory},sid], function (err,r) {
            if (err) {
                throw err;
            }
            callback(err,r);
            connection.release(); 
        });
    });
}
module.exports.createsong = function (songname,price,detail,inventory,path,testpath,callback){

    pool.getConnection(function(err, connection){
        var cmdsid = "select MAX(sid) AS 'MAX' from song" ;
        var cmd2 = "insert into song set ?" ; 
        connection.query(cmdsid, function (err,max){
            if (err){
                return;
            }
                connection.query(cmd2,{sid:max[0].MAX+1,songname:songname,price:price,detail:detail,inventory:inventory,path:path,testpath:testpath,sell:0}, function (err,r) {
                    if (err) {
                        throw err;
                    }
                    callback(err,r);
                    connection.release(); 
                });
        });
    });
}


  